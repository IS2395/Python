
# Online Python - IDE, Editor, Compiler, Interpreter

meses=('Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre')
mes=int(input('Introduce un numero del 1 al 12, para salir introduce 0: '))
while mes != 0:
  if mes in range(1,13):
    print(meses[mes-1])
  else:
    print('Numero fuera del rango')
  mes=int(input('Introduce un numero del 1 al 12, para salir introduce 0: '))