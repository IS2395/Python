
# Online Python - IDE, Editor, Compiler, Interpreter

numero=int(input('Ingresa un numero: '))
if numero > 0:
  print(f'El numero {numero} es un numero positivo')
else:
  print(f'El numero {numero} es un numero negativo')  