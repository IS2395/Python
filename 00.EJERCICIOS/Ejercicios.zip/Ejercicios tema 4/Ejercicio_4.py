
# Online Python - IDE, Editor, Compiler, Interpreter

alumnos={}
veces=int(input('Cuantos alumnos vas a registrar: '))
while veces>0:
  nombre_alumno=input('Nombre del alumno: ')
  if nombre_alumno in alumnos:
    print('El alumno ya se registro')
  else:
    notas=[]
    calif=float(input('Ingresa la primera calificación: '))
    while calif>=0:
      notas.append(calif)
      calif=float(input('Ingresa la siguiente calificación: '))
    promedio=sum(notas)/len(notas)  
    alumnos.update({nombre_alumno:promedio})
    veces=veces-1

clase=alumnos.items()
for k,v in clase:
  print(f'Nombre del alumno: {k} Promedio: {v}')