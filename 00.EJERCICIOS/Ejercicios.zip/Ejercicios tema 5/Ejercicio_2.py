
# Online Python - IDE, Editor, Compiler, Interpreter

rango=int(input('Introduce un numero: '))
if rango >=1 and rango <=7:
  print(f'El numero {rango} esta en el rango de 1 a 7')
else:  
  print(f'El numero {rango} no esta en el rango de 1 a 7')