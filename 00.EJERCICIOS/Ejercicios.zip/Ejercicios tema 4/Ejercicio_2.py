
# Online Python - IDE, Editor, Compiler, Interpreter

lista=['a','b','c','d','e']
lista[0]=input('Introduce el primer valor de la lista: ')
lista[1]=input('Introduce el segundo valor de la lista: ')
lista[2]=input('Introduce el tercer valor de la lista: ')
lista[3]=input('Introduce el cuarto valor de la lista: ')
lista[4]=input('Introduce el quinto valor de la lista: ')
print(f'Se genero la lista: {lista}')
l_inv=lista
l_inv.sort(reverse=True)
print(f'Lista invertida: {l_inv}')