
# Online Python - IDE, Editor, Compiler, Interpreter

print('''MENU DE RECOMENDACIONES
1. Literatura
2. Cine
3. Musica
4. Videojuegos
5. Salir
Introduce el numero del menu que deseas visitar:  ''')
menu=int(input(''))
while menu != 5:
  if menu == 1:
    print('''Lecturas recomendables: 
    - Esperándolo a Tito y otros cuentos de fútbol (Eduardo Sacheri)
    - El juego de Ender (Orson Scott Card)
    - El sueño de los héroes (Adolfo Bioy Casares) ''')
    
  elif menu == 2:
    print('''Peliculas recomendables:
    - Matriz (1999)
    - El ultimo samurai (2003)
    - Cars (2006) ''')
  elif menu == 3:
    print('''Discos recomendables: 
    - Despedazado por mil partes (La Renga, 1996)
    - Búfalo (La Mississippi, 2008)
    - Gaia (Mago de Oz, 2003) ''')
  elif menu == 4:
    print('''Videojuegos clasicos recomendables: 
    - Día del tentáculo (LucasArts, 1993)
    - Terminal Velocity (Terminal Reality/3D Realms, 1995)
    - Death Rally (Remedy/Apogee, 1996)''')
  elif menu == 5:
    print('Gracias, vuelva pronto')
  else:
    print('Opcion no valida')
  print('''MENU DE RECOMENDACIONES
1. Literatura
2. Cine
3. Musica
4. Videojuegos
5. Salir
Introduce el numero del menu que deseas visitar:  ''')
  menu=int(input(''))