
# Online Python - IDE, Editor, Compiler, Interpreter

numero=int(input('Ingresa un numero: '))
for i in range(2,numero):
  divisor=0
  for n in range(2,i):
    if i % n == 0:
      divisor=divisor+1
  if divisor == 0:
    print(f'El numero {i} es numero primo')