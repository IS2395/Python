
# Online Python - IDE, Editor, Compiler, Interpreter

notas=[1,2,3,4,5]
notas[0]=int(input('Introduce la primera nota: '))
notas[1]=int(input('Introduce la segunda nota: '))
notas[2]=int(input('Introduce la tercera nota: '))
notas[3]=int(input('Introduce la cuarta nota: '))
notas[4]=int(input('Introduce la quinta nota: '))
print(f'Las notas del alumno son: {notas}')
print(f'El promedio del alumno es: {(notas[0]+notas[1]+notas[2]+notas[3]+notas[4])/5}')
print(f'La calificacion mas alta es: {max(notas)}')
print(f'La calificacion mas baja es: {min(notas)}')
     