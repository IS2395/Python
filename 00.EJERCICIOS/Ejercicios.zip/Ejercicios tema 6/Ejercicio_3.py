
# Online Python - IDE, Editor, Compiler, Interpreter

pagos=[]
pago_mes=10
for mes in range (1,21):
  pagos.append(pago_mes)
  print (f'Pago en el mes {mes}: {pago_mes} €')
  pago_mes=pago_mes+10
total=sum(pagos)
print(f'El total que se pago fue de {total} €')