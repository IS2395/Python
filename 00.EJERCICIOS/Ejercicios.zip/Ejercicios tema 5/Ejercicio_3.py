
# Online Python - IDE, Editor, Compiler, Interpreter

monto=float(input('Ingresa el monto: '))
porciento=float(input('Ingresa el % de interes mensual: '))
interes=monto*(porciento/100)
if porciento >= 30:
  total=monto+interes
  print(f'El importe total con el {porciento}% de intereses es de {total}')
else:
  print(f'El importe total es de {monto}')