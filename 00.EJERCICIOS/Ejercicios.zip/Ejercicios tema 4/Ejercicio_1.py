
# Online Python - IDE, Editor, Compiler, Interpreter

import random
 
lista=list(range(1,11))
random.shuffle(lista)
print(f'Se genero la lista: {lista}')
print(f'{lista[0]} ({lista[0]})^2={(lista[0])**2} ({lista[0]})^3={(lista[0])**3} ')
print(f'{lista[1]} ({lista[1]})^2={(lista[1])**2} ({lista[1]})^3={(lista[1])**3} ')
print(f'{lista[2]} ({lista[2]})^2={(lista[2])**2} ({lista[2]})^3={(lista[2])**3} ')
print(f'{lista[3]} ({lista[3]})^2={(lista[3])**2} ({lista[3]})^3={(lista[3])**3} ')
print(f'{lista[4]} ({lista[4]})^2={(lista[4])**2} ({lista[4]})^3={(lista[4])**3} ')
print(f'{lista[5]} ({lista[5]})^2={(lista[5])**2} ({lista[5]})^3={(lista[5])**3} ')
print(f'{lista[6]} ({lista[6]})^2={(lista[6])**2} ({lista[6]})^3={(lista[6])**3} ')
print(f'{lista[7]} ({lista[7]})^2={(lista[7])**2} ({lista[7]})^3={(lista[7])**3} ')
print(f'{lista[8]} ({lista[8]})^2={(lista[8])**2} ({lista[8]})^3={(lista[8])**3} ')
print(f'{lista[9]} ({lista[9]})^2={(lista[9])**2} ({lista[9]})^3={(lista[9])**3} ')