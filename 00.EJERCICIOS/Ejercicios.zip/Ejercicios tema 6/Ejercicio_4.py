
# Online Python - IDE, Editor, Compiler, Interpreter

numero=int(input('Ingresa en el numero del que quieres calcular su factorial: '))
resultado=1
for n in range(2,numero+1):
  resultado=resultado*n
print(f'{numero}!={resultado}')